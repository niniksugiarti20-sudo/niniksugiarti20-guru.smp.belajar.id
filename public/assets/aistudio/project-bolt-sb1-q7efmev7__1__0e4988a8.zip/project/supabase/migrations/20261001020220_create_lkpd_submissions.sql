/*
# Create LKPD submissions table and storage bucket

## Overview
This migration creates the database schema for an electronic worksheet (Lembar Kerja Peserta Didik / LKPD) application about the human respiratory system and protecting respiratory health from PM2.5 haze pollution. The app has two dashboards: a teacher dashboard (accessed via a token) and a student dashboard (accessed by entering name, class, and group).

## New Tables
- `submissions`
  - `id` (uuid, primary key, auto-generated)
  - `student_name` (text, not null) — the student's name
  - `class` (text, not null) — the student's class
  - `group_number` (int, not null) — which group the student belongs to
  - `group_name` (text) — name of the group for LKPD activities
  - `members` (text[]) — list of group member names
  - `pretest_answers` (jsonb) — answers to the pretest questions (keyed by question number)
  - `pretest_score` (int, default 0) — total pretest score
  - `lkpd1_data` (jsonb) — LKPD 1 data: formula table values, text answers, and uploaded photo URLs
  - `lkpd2_data` (jsonb) — LKPD 2 data: organoleptic test table, analysis answers, and uploaded photo URLs
  - `posttest_answers` (jsonb) — answers to the 10 posttest essay questions (keyed by question number, with per-question score)
  - `posttest_score` (int, default 0) — total posttest score
  - `total_score` (int, default 0) — sum of all scores
  - `status` (text, default 'in_progress') — 'in_progress' or 'completed'
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

## Storage
- Creates a public bucket `lkpd-uploads` for student photo uploads (process and result photos)

## Security
- Enables RLS on `submissions`.
- All policies use `TO anon, authenticated` because this is a no-auth single-tenant app (teacher accesses via a hardcoded token in the frontend, students just enter their name).
- Storage policies allow public read and anon/authenticated write to the upload bucket.
*/

CREATE TABLE IF NOT EXISTS submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_name text NOT NULL,
  class text NOT NULL,
  group_number int NOT NULL,
  group_name text,
  members text[],
  pretest_answers jsonb DEFAULT '{}'::jsonb,
  pretest_score int DEFAULT 0,
  lkpd1_data jsonb DEFAULT '{}'::jsonb,
  lkpd2_data jsonb DEFAULT '{}'::jsonb,
  posttest_answers jsonb DEFAULT '{}'::jsonb,
  posttest_score int DEFAULT 0,
  total_score int DEFAULT 0,
  status text DEFAULT 'in_progress',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_submissions" ON submissions;
CREATE POLICY "anon_select_submissions" ON submissions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_submissions" ON submissions;
CREATE POLICY "anon_insert_submissions" ON submissions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_submissions" ON submissions;
CREATE POLICY "anon_update_submissions" ON submissions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_submissions" ON submissions;
CREATE POLICY "anon_delete_submissions" ON submissions FOR DELETE
  TO anon, authenticated USING (true);

-- Storage bucket for student uploads
INSERT INTO storage.buckets (id, name, public)
VALUES ('lkpd-uploads', 'lkpd-uploads', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: public read, anon+authenticated write
DROP POLICY IF EXISTS "anon_read_uploads" ON storage.objects;
CREATE POLICY "anon_read_uploads" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'lkpd-uploads');

DROP POLICY IF EXISTS "anon_insert_uploads" ON storage.objects;
CREATE POLICY "anon_insert_uploads" ON storage.objects FOR INSERT
  TO anon, authenticated WITH CHECK (bucket_id = 'lkpd-uploads');

DROP POLICY IF EXISTS "anon_update_uploads" ON storage.objects;
CREATE POLICY "anon_update_uploads" ON storage.objects FOR UPDATE
  TO anon, authenticated USING (bucket_id = 'lkpd-uploads') WITH CHECK (bucket_id = 'lkpd-uploads');

DROP POLICY IF EXISTS "anon_delete_uploads" ON storage.objects;
CREATE POLICY "anon_delete_uploads" ON storage.objects FOR DELETE
  TO anon, authenticated USING (bucket_id = 'lkpd-uploads');