/*
# Add reflection column to submissions

## Overview
Adds a `reflection` jsonb column to the `submissions` table to store student self-reflection checkboxes completed at the end of the post-test.

## Changes
- `submissions` table: new column `reflection` (jsonb, defaults to empty object)
  - Stores an object like { "senang": true, "paham": false, ... } where keys are reflection item IDs and values are booleans

## Security
- No security changes. Existing RLS policies already cover UPDATE on this table.
*/

ALTER TABLE submissions ADD COLUMN IF NOT EXISTS reflection jsonb DEFAULT '{}'::jsonb;