-- Double all scores from old scale (max 50) to new scale (max 100)
-- Also double per-question scores stored in pretest_answers and posttest_answers JSONB

UPDATE submissions
SET
  pretest_score = pretest_score * 2,
  posttest_score = posttest_score * 2,
  total_score = total_score * 2,
  pretest_answers = (
    SELECT jsonb_object_agg(
      key,
      jsonb_set(
        value,
        '{score}',
        to_jsonb((value->>'score')::int * 2)
      )
    )
    FROM jsonb_each(pretest_answers)
  ),
  posttest_answers = (
    SELECT jsonb_object_agg(
      key,
      jsonb_set(
        value,
        '{score}',
        to_jsonb((value->>'score')::int * 2)
      )
    )
    FROM jsonb_each(posttest_answers)
  ),
  updated_at = now();